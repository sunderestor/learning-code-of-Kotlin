
import java.math.BigInteger
import java.math.BigDecimal
import java.math.RoundingMode

fun main() {
    var exit = false
    while (!exit){
        println("Enter two numbers in format: {source base} {target base} (To quit type /exit)")
        val firstread = readln()
        if (firstread != "/exit") {
            val splitfirstread = firstread.split(" ")
            val sourcebase: Int = splitfirstread[0].toInt()
            val targetbase: Int = splitfirstread[1].toInt()
            var back = false
            while(!back) {
                println("Enter number in base $sourcebase to convert to base $targetbase (To go back type /back)")
                val numberToConv: String = readln()
                if (numberToConv != "/back") {
                    var convResult = numberToConv

                    if (sourcebase != 10) convResult = convToDeci(sourcebase, numberToConv)
                    if (targetbase != 10) convResult = deciToTargetbase(convResult, targetbase)
                    println("Conversion result: $convResult")
                    println("")
                } else {
                    back = true
                    println("")
                }
            }
        } else {
            exit = true
        }
    }
}

fun convToDeci(sourcebase: Int, numberToConv: String):String {
    var sum = 0.toBigInteger()
    var tmpnum: BigInteger
    var fractionSum  = "0".toBigDecimal()
    if (numberToConv.substringBefore(".") == numberToConv) {
        for (i in numberToConv.length - 1 downTo 0) {
            if (numberToConv[i].code < 'a'.code) {
                tmpnum = numberToConv[i].toString().toBigInteger()
            } else {
                tmpnum = latinToInt(numberToConv[i]).toBigInteger()
            }
            if (i != numberToConv.length - 1) {
                for (j in 0..numberToConv.length - 2 - i) {
                    tmpnum *= sourcebase.toBigInteger()
                }
            }
            sum += tmpnum
        }
    } else {
        val fractionalPart = numberToConv.substringAfter(".")
        val integerpart = numberToConv.substringBefore(".")
        var tmpnume: BigInteger
        for (i in integerpart.length - 1 downTo 0) {
            if (integerpart[i].code < 'a'.code) {
                tmpnume = integerpart[i].toString().toBigInteger()
            } else {
                tmpnume = latinToInt(integerpart[i]).toBigInteger()
            }
            if (i != integerpart.length - 1) {
                for (j in 0..integerpart.length - 2 - i) {
                    tmpnume *= sourcebase.toBigInteger()
                }
            }
            sum += tmpnume
        }

        for(j in 0 .. 4) {
            var fractiontmp: BigDecimal
            if (fractionalPart[j].code >= 'a'.code)  {
                fractiontmp = latinToInt(fractionalPart[j]).toBigDecimal()
            } else {
                fractiontmp = fractionalPart[j].toString().toBigDecimal()
            }
            for(k in 0..j) {
                fractiontmp = fractiontmp.setScale(5, RoundingMode.HALF_EVEN) / sourcebase.toBigDecimal()
            }
            fractionSum += fractiontmp
        }
    }
    return (sum.toBigDecimal() + fractionSum).toString()
}

fun latinToInt(latin: Char):Int {
    return latin.code - 87
}

fun deciToTargetbase(deci: String, targetbase: Int): String {
    val fractionPart = deci.toBigDecimal() % BigDecimal.ONE
    val integerPart = deci.toBigDecimal() - fractionPart
    var temp = integerPart.toBigInteger()
    var catter = ""
    var remd: Int
    val aToZ = "abcdefghijklmnopqrstuvwxyz"
    while(temp != 0.toBigInteger()){
        remd = (temp % targetbase.toBigInteger()).toInt()
        temp /= targetbase.toBigInteger()
        if (remd < 10) {
            catter = remd.toString() + catter
        } else {
         catter = aToZ[remd - 10] + catter
        }
    }
    var fractionTmp = fractionPart
    var remderTmp: BigDecimal = BigDecimal(0)
    var integerTmp: BigDecimal = BigDecimal(0)
    if (fractionPart != BigDecimal.ZERO) {
        catter += "."
        for (i in 0..4) {
            fractionTmp *= targetbase.toBigDecimal()
            remderTmp = fractionTmp % BigDecimal.ONE
            integerTmp = fractionTmp - remderTmp
            fractionTmp = remderTmp
            if(integerTmp >= BigDecimal.TEN) {
                catter += aToZ[integerTmp.toInt() - 10]
            } else {
                catter += integerTmp.toInt().toString()
            }
        }
    }
    return catter
}

